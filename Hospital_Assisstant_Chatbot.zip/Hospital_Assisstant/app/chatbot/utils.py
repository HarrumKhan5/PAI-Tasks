import os
import faiss
import pickle
import PyPDF2
from sklearn.feature_extraction.text import TfidfVectorizer

def load_pdf_chunks(pdf_path, chunk_size=150):
    reader = PyPDF2.PdfReader(pdf_path)
    text = ''
    for page in reader.pages:
        text += page.extract_text() + ' '
    chunks = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]
    return chunks

def build_faiss_index(chunks):
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(chunks)
    index = faiss.IndexFlatL2(X.shape[1])
    index.add(X.toarray())
    return index, vectorizer
