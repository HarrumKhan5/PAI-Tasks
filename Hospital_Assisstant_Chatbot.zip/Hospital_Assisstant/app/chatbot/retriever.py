def retrieve_documents(query, chunks, index, vectorizer, top_k=8):
    query_vec = vectorizer.transform([query]).toarray()
    D, I = index.search(query_vec, top_k)
    return [chunks[i] for i in I[0]]

