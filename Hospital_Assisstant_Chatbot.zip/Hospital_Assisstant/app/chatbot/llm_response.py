from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import torch
tokenizer = AutoTokenizer.from_pretrained("google/flan-t5-base")
model = AutoModelForSeq2SeqLM.from_pretrained("google/flan-t5-base")
def generate_response(user_query, context):
    context_text = " ".join(context)
    # prompt = (
    #     f"Context:\n{context_text}\n\n"
    #     f"Question:\n{user_query}\n\n"
    #     "Answer in a clear and complete sentence:"
    # )
    prompt = (
    f"You are a smart and friendly hospital assistant chatbot. Your job is to help users by answering their "
    f"questions based on hospital-related information such as doctors, services, timings, departments, or facilities.\n"
    f"If the user asks a general or casual question (like greeting, farewell, or thanks), reply politely and naturally.\n\n"
    f"Context:\n{context_text}\n\n"
    f"User: {user_query}\n"
    f"Chatbot:"
)


    inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
    output_ids = model.generate(
        inputs["input_ids"],
        max_length=512,
        num_return_sequences=1,
        early_stopping=True
    )
    response = tokenizer.decode(output_ids[0], skip_special_tokens=True)
    return response
