from flask import Flask, render_template, request
from chatbot.utils import load_pdf_chunks, build_faiss_index
from chatbot.retriever import retrieve_documents
from chatbot.llm_response import generate_response

app = Flask(__name__)
chunks = load_pdf_chunks("embeddings/hospital_info.pdf")
faiss_index, vectorizer = build_faiss_index(chunks)  

@app.route("/", methods=["GET", "POST"])
def chat():  
    answer = ""
    if request.method == "POST":
        query = request.form["query"]
        docs = retrieve_documents(query, chunks, faiss_index, vectorizer)
        answer = generate_response(query, docs)
    return render_template("index.html", answer=answer)

if __name__ == "__main__":
    app.run(debug=True)
