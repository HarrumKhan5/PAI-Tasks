from flask import Flask, render_template
import requests
import os
app = Flask(__name__, template_folder="templates")
NASA_API = os.getenv("NASA_API_KEY", "DEMO_KEY")
APOD_URL = "https://api.nasa.gov/planetary/apod"
@app.route("/", methods=["GET"])
def index():
    try:
        params = {"api_key": NASA_API}
        response = requests.get(APOD_URL, params=params)
        response.raise_for_status()  
        apod_data = response.json()
        if not apod_data or "error" in apod_data:
            apod_data = {"error": "No valid data received from NASA API"}    
    except requests.exceptions.RequestException as e:
        apod_data = {"error": "Failed to fetch data from NASA API", "details": str(e)}
    return render_template("index.html", apod=apod_data)
if __name__ == "__main__":
    print("🚀 Flask App is Running at http://127.0.0.1:5000/")
    app.run(debug=True)
