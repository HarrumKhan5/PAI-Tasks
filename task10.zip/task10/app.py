from flask import Flask, render_template, request, jsonify
app = Flask(__name__)
def hospital_chatbot_response(user_input):
    responses = {
        "timing": "We are open from 8 AM to 8 PM, Monday-Saturday.",
        "location": "The hospital is located at 123 Health Street,Lahore.",
        "appointment": "You can book an appointment by calling 123-456-7890.",
        "emergency": "In case of emergency, dial 1122 or visit our Emergency Wing directly.",
        "doctors":	"We have specialists in cardiology, neurology, pediatrics, and more.",
        "departments":	"Our departments include Cardiology, Orthopedics, Neurology, Pediatrics, and General Medicine.",
        "pharmacy":	"Our pharmacy is open from 9 AM to 9 PM .",
        "lab":"Our diagnostics lab offers blood tests, X-rays, MRIs, and more."
    }
    for keyword in responses:
        if keyword in user_input.lower():
            return responses[keyword]
    return "Sorry, I couldn't understand that. Could you please rephrase?"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    user_message = request.json.get("message")
    response = hospital_chatbot_response(user_message)
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
