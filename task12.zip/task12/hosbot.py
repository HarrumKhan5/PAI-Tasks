import pandas as pd
import gradio as gr
df = pd.read_csv("hospital_data.csv") 
df.head()
def search_hospital_info(query):
    query_lower = query.lower()
    results = []
    for _, row in df.iterrows():
        if query_lower in row["Title"].lower() or query_lower in row["Details"].lower():
            results.append(f"{row['Category']}: {row['Title']}\n{row['Details']}")
    if results:
        return "\n\n".join(results)
    else:
        return "Sorry, I couldn't find any info related to your query.Please try again."
iface = gr.Interface(fn=search_hospital_info,
                     inputs="text",
                     outputs="text",
                     title="Hospital Chatbot",
                     description="Ask me about departments, services, doctors, or general hospital info.")

iface.launch()
